"""TVRA: explainable, local vehicle trajectory assessment."""

__version__ = "3.0.1"
RULE_VERSION = "2026.10-v2"
