#!/usr/bin/env python3
"""Run inside the delivered Windows runtime; uses a temporary synthetic DB."""
from __future__ import annotations

import argparse
import json
import os
import platform
import sqlite3
import sys
import tempfile
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
EXPECTED_PYTHON = (3, 8, 10)


def check_runtime():
    """Verify that the smoke test is running with the bundled runtime."""
    version = sys.version_info[:3]
    if version != EXPECTED_PYTHON:
        raise RuntimeError(
            "Expected bundled Python {}.{}.{}; found {}.{}.{}".format(
                *EXPECTED_PYTHON, *version
            )
        )
    runtime = ROOT / "runtime" / "python.exe"
    if os.name == "nt":
        if not runtime.is_file():
            raise RuntimeError("Bundled runtime is missing: {}".format(runtime))
        if Path(sys.executable).name.lower() != runtime.name.lower():
            raise RuntimeError("Smoke test is not running from the bundled Python runtime")
    with sqlite3.connect(":memory:") as db:
        db.execute("CREATE TABLE smoke_check (value INTEGER NOT NULL)")
        db.execute("INSERT INTO smoke_check VALUES (1)")
        value = db.execute("SELECT value FROM smoke_check").fetchone()[0]
    if value != 1:
        raise RuntimeError("SQLite round-trip check failed")
    print("SQLite:", sqlite3.sqlite_version)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--show", action="store_true", help="Display the actual Qt main window for two seconds")
    args = parser.parse_args()
    print("TVRA runtime diagnostic")
    print("Platform:", platform.platform())
    print("Python:", sys.version.replace("\n", " "))
    print("Pointer size:", platform.architecture()[0])
    check_runtime()
    if not args.show:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide2 import QtCore, QtWidgets
    from tvra.service import Service
    from tvra.gui import MainWindow
    from tvra.reports import create_template, export_rankings, export_vehicle_report

    pyside_dir = Path(QtCore.__file__).resolve().parent
    required_qt = [
        pyside_dir / "Qt5Core.dll",
        pyside_dir / "Qt5Gui.dll",
        pyside_dir / "Qt5Widgets.dll",
        pyside_dir / "pyside2.abi3.dll",
        pyside_dir / "plugins" / "platforms" / "qwindows.dll",
        pyside_dir / "plugins" / "platforms" / "qoffscreen.dll",
    ]
    missing_qt = [str(path) for path in required_qt if not path.is_file()]
    if missing_qt:
        raise RuntimeError("Required Qt/PySide2 files are missing: " + "; ".join(missing_qt))
    print("Qt DLL directory:", pyside_dir)

    print("Qt:", QtCore.qVersion())
    with tempfile.TemporaryDirectory(prefix="tvra-smoke-") as temporary:
        folder = Path(temporary)
        service = Service(folder / "data")
        template = folder / "template.xlsx"
        create_template(str(template))
        # A blank template is intentionally not a data batch.  Verify its
        # structure, then exercise the import path with the bundled synthetic
        # demo workbook (which contains no real vehicle or enterprise data).
        from openpyxl import load_workbook
        workbook = load_workbook(str(template), read_only=True)
        try:
            assert workbook.sheetnames == ["过车数据", "填写说明"]
        finally:
            workbook.close()
        result = service.import_files([str(ROOT / "samples" / "demo.xlsx")])
        print("Demo import:", json.dumps(result, ensure_ascii=True))
        summary = service.summary()
        print("Summary:", json.dumps(summary, ensure_ascii=True))
        ranking_report = folder / "report.xlsx"
        export_rankings(service.list_vehicles(), service.list_events(), str(ranking_report))
        if not ranking_report.is_file() or ranking_report.stat().st_size == 0:
            raise RuntimeError("Excel report was not generated")
        vehicles = service.list_vehicles()
        if not vehicles:
            raise RuntimeError("Demo import produced no vehicles for report validation")
        vehicle_report = folder / "vehicle-report.docx"
        detail = service.vehicle_detail(vehicles[0]["vehicle_key"])
        export_vehicle_report(detail, str(vehicle_report), summary)
        if not vehicle_report.is_file() or vehicle_report.stat().st_size == 0:
            raise RuntimeError("Word report was not generated")
        app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv[:1])
        window = MainWindow(service)
        if args.show:
            window.show()
        QtCore.QTimer.singleShot(2000 if args.show else 100, app.quit)
        app.exec_()
        window.close()
        service.close()
    print("PASS: Python runtime, SQLite, XLSX/Word reports and Qt main window completed. No existing user data was changed.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        traceback.print_exc()
        print("FAIL: see the traceback above. On Windows 7, first check SP1 and the Universal C Runtime update.")
        sys.exit(1)
